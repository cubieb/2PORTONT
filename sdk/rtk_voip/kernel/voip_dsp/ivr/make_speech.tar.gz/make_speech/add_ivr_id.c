#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <curses.h>
#include <stdlib.h>

/*
 * An ID should add to:
 *  - ../ivr_speech_table.c
 *    ID1: _M_IVR_SPEECH_WAVE_INFO( text_xxx )
 *    ID2: case IVR_TEXT_ID_xxx:
 *    ID6:     return IVR_SPEECH_ID_TXT_xxx;
		   break;
 *  - ../ivr.h
 *    ID3: IVR_SPEECH_ID_TXT_xxx
 *  - ./make_ivr_speech.c
 *    ID4: _M_FILE( xxx )
 *  - ../../../include/voip_params.h
 *    ID5: IVR_TEXT_ID_xxx
 */

#define ID_FLAGS_NONE			0x0000
#define ID_FLAGS_UPPER_CASE		0x0001	/* text_fixIP --> TEXT_FIXIP */
#define ID_FLAGS_USE_TXT		0x0002	/* TEXT_FIXIP --> TXT_FIXIP */
#define ID_FLAGS_STRIP_TEXT		0x0004	/* TEXT_FIXIP --> FIXIP */

#define NUM_OF_TARGET			3
#define MAX_ID_LENGTH			256
#define MAX_LINE_LENGTH			1024

typedef struct search_s {
	const char *pszTarget;
	const char *pszAddFormat;
	unsigned int id_flags;
} search_t;

typedef struct filelist_s {
	const char *pszFilename;
	const search_t *target[ NUM_OF_TARGET ];
} filelist_t;

const search_t search_ID1 = { "///<<&&ID1&&>>", "\t_M_IVR_SPEECH_WAVE_INFO( %s ),\n", ID_FLAGS_NONE };
const search_t search_ID2 = { "///<<&&ID2&&>>", "\t\tcase IVR_TEXT_ID_%s:\n", ID_FLAGS_UPPER_CASE | ID_FLAGS_STRIP_TEXT };
const search_t search_ID2_1 = { "///<<&&ID2&&>>", "\t\t\treturn IVR_SPEECH_ID_%s;\n\t\t\tbreak;\n", ID_FLAGS_UPPER_CASE | ID_FLAGS_USE_TXT };
const search_t search_ID3 = { "///<<&&ID3&&>>", "\tIVR_SPEECH_ID_%s,\n", ID_FLAGS_UPPER_CASE | ID_FLAGS_USE_TXT };
const search_t search_ID4 = { "///<<&&ID4&&>>", "\t_M_FILE( %s ),\n", ID_FLAGS_NONE };
const search_t search_ID5 = { "///<<&&ID5&&>>", "\tIVR_TEXT_ID_%s,\n", ID_FLAGS_UPPER_CASE | ID_FLAGS_STRIP_TEXT };

const filelist_t file_list[] = {
	{ "../ivr_speech_table.c", { &search_ID1, &search_ID2, &search_ID2_1 } },
	{ "../ivr.h", { &search_ID3, NULL, NULL } },
	{ "./make_ivr_speech.c", { &search_ID4, NULL, NULL } },
	{ "../../../include/voip_params.h", { &search_ID5, NULL, NULL } },
};

#define NUM_OF_FILELIST		( sizeof( file_list ) / sizeof( file_list[ 0 ] ) )

/* --------------------------------------------------------------------------- */
/* check file for new ID */
const char *pszCfgFilename = { "add_ivr_id.cfg" };

int CheckIfNovelNewId( const char *pszNewId )
{
	FILE *fp;
	char szBuffer[ MAX_LINE_LENGTH ];
	int index;
	char ch;
	int ret = 0;
	
	if( !( fp = fopen( pszCfgFilename, "r" ) ) ) {
		printf( "Can't open '%s', so skip to check novel new ID.\n", pszCfgFilename ); 
		return 0;
	}
	
	while( !feof( fp ) ) {
		fgets( szBuffer, MAX_LINE_LENGTH, fp );
		
		index = strlen( szBuffer ) - 1;
		
		/* remove tail new line or space */
		while( index ) {
			ch = szBuffer[ index ];
			
			if( ch == ' ' || ch == '\r' || ch == '\n' || ch == '\t' )
				szBuffer[ index ] = '\x0';
			else
				break;
			
			index --;
		}

		if( strcmp( pszNewId, szBuffer ) == 0 ) {
			ret = 1;
			printf( "'%s' is not a novel ID.\n", pszNewId );
			goto label_check_novel_id_done;
		}
	}

label_check_novel_id_done:	
	fclose( fp );
	
	return ret;
}

int AppendNovelNewId( const char *pszNewId )
{
	FILE *fp;

	if( !( fp = fopen( pszCfgFilename, "a" ) ) ) {
		printf( "Can't open '%s' to write??.\n", pszCfgFilename ); 
		return 1;
	}
	
	fputs( pszNewId, fp );
	fputs( "\n", fp );

	fclose( fp );

	return 0;
}

int CheckFileForNewId( const char *pszNewId )
{
	char szFilename[ MAX_ID_LENGTH + 1 ];
	struct stat bufstat;
	
	sprintf( szFilename, "./res/%s.snd", pszNewId );
	
	if( stat( szFilename, &bufstat ) ) {
		printf( "File '%s' not exist\n", szFilename );
		return 1;
	}
	
	return 0;
}

/* --------------------------------------------------------------------------- */
/* ID generator */
char szIdPlain[ MAX_ID_LENGTH + 1 ];			/* text_fixIP */
char szIdUpperCase[ MAX_ID_LENGTH + 1 ];		/* TEXT_FIXIP */
char szIdUpperStripText[ MAX_ID_LENGTH + 1 ];	/* FIXIP */
char szIdUpperUseTxt[ MAX_ID_LENGTH + 1 ];		/* TXT_FIXIP */

char *strupr( char *psz )
{
	char ch;
	
	while( ( ch = *psz ) ) {
		if( ch >= 'a' && ch <= 'z' ) {
			ch = 'A' + ch - 'a';
			*psz = ch;
		}
		
		psz ++;
	}
	
	return psz;
}

int GenerateIdSet( const char *pszId )
{
	int len;
	
	/* No ID is given, so enter ID now */
	if( pszId == NULL ) {
		printf( "Please enter ID to add: " );
		scanf( "%s", szIdPlain );
		pszId = szIdPlain;
	}
	
	/* check ID length */
	len = strlen( pszId );
	
	if( len > MAX_ID_LENGTH ) {
		printf( "Length of ID is too long. (max:%d)\n", MAX_ID_LENGTH );
		return 1;
	} else if( len == 0 ) {
		printf( "Length of ID is zero.\n" );
		return 1;
	}
	
	/* check file in ./res */
	if( CheckFileForNewId( pszId ) )
		return 1;
	
	/* check Id is exist or not */
	if( CheckIfNovelNewId( pszId ) )
		return 1;
	
	/* 1. copy to szIdPlain[] */
	if( pszId != szIdPlain )
		strcpy( szIdPlain, pszId );
		
	/* 2. szIdUpperCase[] */
	strcpy( szIdUpperCase, szIdPlain );
	strupr( szIdUpperCase );
	
	/* 3. szIdUpperStripText[], 4. szIdUpperUseTxt[] */
	if( strncmp( szIdUpperCase, "TEXT_", 5 ) == 0 ) {
		/* 3. */
		strcpy( szIdUpperStripText, &szIdUpperCase[ 5 ] );
		/* 4. */
		strcpy( szIdUpperUseTxt, "TXT_" );
		strcat( szIdUpperUseTxt, &szIdUpperCase[ 5 ] );
	} else {
		printf( "NOTE: ID prefix is not 'TEXT_'.\n" );
		/* 3. */
		strcpy( szIdUpperStripText, szIdUpperCase );
		/* 4. */
		strcpy( szIdUpperUseTxt, szIdUpperCase );
	}
	
	return 0;
}

int GetLineBySearchEntry( const search_t *pszSearch, char *pszOutputLine )
{
	const char *pszId;
	
	switch( pszSearch ->id_flags ) {
		case ID_FLAGS_NONE:
			pszId = szIdPlain;
			break;
		case ( ID_FLAGS_UPPER_CASE | ID_FLAGS_STRIP_TEXT ):
			pszId = szIdUpperStripText;
			break;
		case ( ID_FLAGS_UPPER_CASE | ID_FLAGS_USE_TXT ):
			pszId = szIdUpperUseTxt;
			break;
		default:
			pszId = NULL;
			break;
	}
	
	if( pszId == NULL ) {
		printf( "ERROR: Not support this flags??\n" );
		return 1;	/* not support this flags?? */
	}
	
	sprintf( pszOutputLine, pszSearch ->pszAddFormat, pszId );

	return 0;
}

/* --------------------------------------------------------------------------- */
int AnalyzeOneFile( const filelist_t *pFilelist )
{
	int ret = 0;
	int rTarget;
	FILE *fpSrc, *fpDest;
	char szItmFilename[ 256 ];
	char szLine[ MAX_LINE_LENGTH + 1 ];
	char szLineNovel[ MAX_LINE_LENGTH + 1 ];
	int nFoundTarget[ NUM_OF_TARGET ] = { 0, 0, 0 };
#if NUM_OF_TARGET != 3
	???
#endif
	
	strcpy( szItmFilename, pFilelist ->pszFilename );
	strcat( szItmFilename, ".itm" );

	/* open src */
	if( !( fpSrc = fopen( pFilelist ->pszFilename, "r" ) ) ) {
		printf( "Open %s fail\n", pFilelist ->pszFilename );
		return 1;
	}
	
	printf( "  Analyze %s...\n", pFilelist ->pszFilename );
	
	/* open dest */
	if( !( fpDest = fopen( szItmFilename, "w" ) ) ) {
		printf( "Open %s fail\n", szItmFilename );
		goto label_safe_end__close_src;
	}
	
	while( !feof( fpSrc ) ) {
		
		if( fgets( szLine, MAX_LINE_LENGTH, fpSrc ) == 0 )
			break;
	
		for( rTarget = 0; rTarget < NUM_OF_TARGET; rTarget ++ ) {
			if( pFilelist ->target[ rTarget ] == NULL )
				break;
				
			if( strstr( szLine, pFilelist ->target[ rTarget ] ->pszTarget ) ) {
				/* found !! */
				nFoundTarget[ rTarget ] ++;
				
				if( GetLineBySearchEntry( pFilelist ->target[ rTarget ], szLineNovel ) )
					goto label_safe_end__close_dest_src;
				
				fputs( szLineNovel, fpDest );
			}
		} // each target 
		
		fputs( szLine, fpDest );
	}
	
	/* check found */
	for( rTarget = 0; rTarget < NUM_OF_TARGET; rTarget ++ ) {
		if( pFilelist ->target[ rTarget ] == NULL )
				break;
				
		if( pFilelist ->target[ rTarget ] && nFoundTarget[ rTarget ] == 1 )
			;
		else {
			printf( "    Target %s was found in %s with count %d\n", pFilelist ->target[ rTarget ] ->pszTarget, pFilelist ->pszFilename, nFoundTarget[ rTarget ] );
			ret = 1;
			break;
		}
	}

label_safe_end__close_dest_src:	
	fclose( fpDest );

label_safe_end__close_src:	
	fclose( fpSrc );
	
	return ret;
}

int BackupAndOverwriteOneFile( const filelist_t *pFilelist )
{
	int ret;
	char szItmFilename[ 256 ];
	char szBakFilename[ 256 ];
	char szCmd[ 512 ];
	
	/* intermedia file */
	sprintf( szItmFilename, "%s.itm", pFilelist ->pszFilename );
	
	/* backup file */
	sprintf( szBakFilename, "%s.bak", pFilelist ->pszFilename );
	
	/* command 1: original --> .bak */
	sprintf( szCmd, "cp %s %s -f", pFilelist ->pszFilename, szBakFilename );
	
	printf( "  %s\n", szCmd );
	
	if( ( ret = system( szCmd ) ) ) {
		printf( "fail to execute '%s'.\n", szCmd );
		return ret;
	}
	
	/* command 2: .itm --> original */
	sprintf( szCmd, "cp %s %s -f", szItmFilename, pFilelist ->pszFilename );

	printf( "  %s\n", szCmd );
	
	if( ( ret = system( szCmd ) ) ) {
		printf( "fail to execute '%s'.\n", szCmd );
		return ret;
	}
	
	return 0;
}

/* --------------------------------------------------------------------------- */
/* main program */

int main( int argc, char **argv )
{
	int rFile;
	int ret;
	char ch;
	
	/* first argument is ID */
	if( ( ret = GenerateIdSet( ( argc >= 2 ? argv[ 1 ] : NULL ) ) ) )
		return ret;
	
	/* analyze file to generate intermedia file */
	for( rFile = 0; rFile < NUM_OF_FILELIST; rFile ++ ) {
		if( ( ret = AnalyzeOneFile( &file_list[ rFile ] ) ) )
			return ret;		
	} 
	
	/* backup and overwirte old */
	printf( "Backup old and overwirite them? (Y/N)\n" );
	scanf( "\n%c", &ch );
	
	/* put ID first */
	if( ( ret = AppendNovelNewId( szIdPlain ) ) )
		return ret;
	
	if( ch == 'Y' || ch == 'y' ) {
		for( rFile = 0; rFile < NUM_OF_FILELIST; rFile ++ ) {
			if( ( ret = BackupAndOverwriteOneFile( &file_list[ rFile ] ) ) )
				return ret;		
		} 
	}
	
	return 0;
}
